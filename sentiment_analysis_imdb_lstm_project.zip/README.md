
# Sentiment Analysis of IMDb Movie Reviews Using LSTM Networks

## Project Overview
This project develops a deep learning model to perform sentiment analysis on the IMDb movie review dataset. It aims to classify movie reviews as positive or negative, utilizing Natural Language Processing (NLP) and Long Short-Term Memory (LSTM) networks.

## Dataset
The IMDb movie review dataset comprises 50,000 reviews, evenly divided into training and test sets for binary sentiment classification.

## Key Features
- **Data Preprocessing**: Tokenization and sequence padding ensure uniform input size for neural network processing.
- **Model Architecture**: Utilizes an Embedding layer, an LSTM layer, and Dense layers with dropout and L2 regularization to address overfitting.
- **Training and Evaluation**: The model achieves notable accuracy, demonstrating its effectiveness in sentiment classification.

## Technologies Used
- Python
- TensorFlow
- Keras

## How to Run
Ensure you have Python and the required libraries installed, then run the script `sentiment_analysis_imdb_lstm.py` to train the model and evaluate its performance.

## License
This project is open source and available under the MIT License.
